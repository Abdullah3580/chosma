# Chosma User Auth & Profile

## এই ফাইলগুলো মূল chosma প্রজেক্টে কপি করো

### কোথায় কপি করবে:
- `app/auth/` → `E:\chosma\app\auth\`
- `app/account/` → `E:\chosma\app\account\`
- `app/api/auth/` → `E:\chosma\app\api\auth\`
- `app/api/profile/` → `E:\chosma\app\api\profile\`
- `app/api/addresses/` → `E:\chosma\app\api\addresses\`
- `components/account/` → `E:\chosma\components\account\`

### Supabase Dashboard এ করতে হবে:
1. Authentication → URL Configuration → Site URL:
   ```
   https://তোমার-সাইট.vercel.app
   ```
2. Redirect URLs এ যোগ করো:
   ```
   https://তোমার-সাইট.vercel.app/auth/callback
   ```

### Pages:
- `/auth/login` — Login page
- `/auth/signup` — Sign Up page
- `/account` — Profile page
- `/account/orders` — Order history
- `/account/addresses` — Address management
- `/account/password` — Change password
