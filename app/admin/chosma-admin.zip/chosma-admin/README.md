# Chosma Admin Panel

## এই ফাইলগুলো মূল chosma প্রজেক্টে কপি করো

### কোথায় কপি করবে:
- `app/admin/` → `E:\chosma\app\admin\`
- `app/api/admin/` → `E:\chosma\app\api\admin\`
- `components/admin/` → `E:\chosma\components\admin\`
- `middleware.ts` → `E:\chosma\middleware.ts`

### .env.local এ যোগ করো:
```
ADMIN_USERNAME=admin
ADMIN_PASSWORD=তোমার_পাসওয়ার্ড
```

### Vercel এ Environment Variables এ যোগ করো:
```
ADMIN_USERNAME=admin
ADMIN_PASSWORD=তোমার_পাসওয়ার্ড
```

### Admin Panel URL:
https://তোমার-সাইট.vercel.app/admin

### Default Login:
- Username: admin
- Password: chosma2026
